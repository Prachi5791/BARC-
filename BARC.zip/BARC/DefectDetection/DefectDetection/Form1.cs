using OpenCvSharp;
using OpenCvSharp.Extensions;
using System.IO;




namespace DefectDetection
{
    public partial class Form1 : Form
    {

        Mat originalImage;
        Mat processedImage;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {


            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files|*.png;*.jpg;*.bmp";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                originalImage = Cv2.ImRead(ofd.FileName, ImreadModes.Grayscale);
                pictureBox1.Image = BitmapConverter.ToBitmap(originalImage);
                lblResult.Text = "Image Loaded";
            }


        }

        private void btnDetect_Click(object sender, EventArgs e)
        
        {
            if (originalImage == null)
            {
                MessageBox.Show("Load an image first");
                return;
            }

            Mat img = originalImage.Clone();

            // 1. Noise reduction
            Cv2.GaussianBlur(img, img, new OpenCvSharp.Size(5, 5), 0);

            // 2. Thresholding
            Mat binary = new Mat();
            Cv2.AdaptiveThreshold(
                img,
                binary,
                255,
                AdaptiveThresholdTypes.GaussianC,
                ThresholdTypes.BinaryInv,
                11,
                2
            );

            // 3. Morphology
            Mat kernel = Cv2.GetStructuringElement(MorphShapes.Rect, new OpenCvSharp.Size(3, 3));
            Cv2.MorphologyEx(binary, binary, MorphTypes.Open, kernel);
            Cv2.MorphologyEx(binary, binary, MorphTypes.Close, kernel);

            // 4. Find contours
            OpenCvSharp.Point[][] contours;
            HierarchyIndex[] hierarchy;

            Cv2.FindContours(
                binary,
                out contours,
                out hierarchy,
                RetrievalModes.External,
                ContourApproximationModes.ApproxSimple
            );

            Mat output = new Mat();
            Cv2.CvtColor(img, output, ColorConversionCodes.GRAY2BGR);

            int defectCount = 0;

            foreach (var contour in contours)
            {
                double area = Cv2.ContourArea(contour);

                if (area > 50)   // Minimum defect size
                {
                    defectCount++;

                    Rect box = Cv2.BoundingRect(contour);
                    Moments m = Cv2.Moments(contour);

                    int cx = (int)(m.M10 / m.M00);
                    int cy = (int)(m.M01 / m.M00);

                    // Draw box
                    Cv2.Rectangle(output, box, Scalar.Red, 2);

                    // Show coordinates and area
                    string text = $"({cx},{cy}) A={area:F0}";
                    Cv2.PutText(
                        output,
                        text,
                        new OpenCvSharp.Point(box.X, box.Y - 5),
                        HersheyFonts.HersheySimplex,
                        0.4,
                        Scalar.Yellow,
                        1
                    );
                }
            }

            pictureBox1.Image = BitmapConverter.ToBitmap(output);

            if (defectCount > 0)
                lblResult.Text = $"DEFECT FOUND: {defectCount}";
            else
                lblResult.Text = "NO DEFECT FOUND";
        


    }
}
}
